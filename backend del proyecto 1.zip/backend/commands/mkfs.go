package commands

// mkfs.go - implementación autocontenida de MKFS compatible con el proyecto
// Requisitos: tener importadas las rutas del proyecto que ya usas.

import (
	"encoding/binary"
	"fmt"
	"os"
	"strings"
	"time"

	stores "backend/stores"
)

// --- Estructuras mínimas usadas por este mkfs (no tocan otras estructuras del repo) ---

type SuperBlockSimple struct {
	FilesystemType  int32
	InodesCount     int32
	BlocksCount     int32
	FreeBlocksCount int32
	FreeInodesCount int32
	MTime           [20]byte
	UMTime          [20]byte
	MntCount        int32
	Magic           int32
	InodeSize       int32
	BlockSize       int32
	FirstIno        int32
	FirstBlo        int32
	BmInodeStart    int32
	BmBlockStart    int32
	InodeStart      int32
	BlockStart      int32
}

// Tamaños fijos que usaremos (coherentes con enunciado: bloque=64 bytes, inodo tamaño aproximado)
const (
	BlockSizeBytes  = 64
	InodeSizeBytes  = 128            // tamaño elegido razonable para serializar inodo (ajustable)
	SuperBlockBytes = 4*15 + 20 + 20 // aproximación; de todas formas usamos binary.Write
)

// --- Parseador simple para parámetros de mkfs ----
// recibe la línea de parámetros como map[string]string (como tu parser principal construye)
func ParseMkfs(tokens []string) (string, error) {
	id := ""
	ftype := "full" // valor por defecto

	for _, token := range tokens {
		token = strings.TrimSpace(token) // solo trim, no Lower
		if strings.HasPrefix(strings.ToLower(token), "-id=") {
			id = token[len("-id="):] // conservamos mayúsculas
		} else if strings.HasPrefix(strings.ToLower(token), "-type=") {
			ftype = token[len("-type="):]
			if ftype != "full" {
				return "", fmt.Errorf("MKFS ERROR: tipo inválido '%s' (solo 'full')", ftype)
			}
		} else if token != "" {
			return "", fmt.Errorf("MKFS ERROR: parámetro no reconocido '%s'", token)
		}
	}

	if id == "" {
		return "", fmt.Errorf("MKFS ERROR: el parámetro -id es obligatorio")
	}

	if err := Mkfs(id, ftype); err != nil {
		return "", err
	}

	return "MKFS: Formateo completado con éxito", nil
}

// --- Función principal Mkfs ---
// id: id de partición montada (ej: 391A)
// ftype: "full" (por ahora solo full)
func Mkfs(id string, ftype string) error {
	// 1) Resolver id -> path/offset/size: el proyecto define stores.MountedPartitions
	// stores.MountedPartitions debería mapear id -> "path|start|size" o similar.
	// En tu repo se usa MountedPartitions map[string]string = make(map[string]string)
	// Aquí intentamos dos convenciones posibles y las soportamos:
	pathEntry, ok := stores.MountedPartitions[id]
	if !ok {
		// intentamos búsqueda insensible a mayúsculas
		for k, v := range stores.MountedPartitions {
			if strings.EqualFold(k, id) {
				pathEntry = v
				ok = true
				break
			}
		}
		if !ok {
			// mostrar particiones montadas para debug
			fmt.Println("Particiones montadas actualmente:")
			for k, v := range stores.MountedPartitions {
				fmt.Printf("  %s -> %s\n", k, v)
			}
			return fmt.Errorf("partición %s no encontrada o no montada", id)
		}
	}

	// pathEntry podría ser solo la ruta, o la ruta con inicio y tamaño separados por '|'
	var diskPath string
	var partStart int64 = 0
	var partSize int64 = 0

	if strings.Contains(pathEntry, "|") {
		// formato: "/ruta/Disco.mia|start|size"
		parts := strings.Split(pathEntry, "|")
		diskPath = parts[0]
		// intentar parse start y size si existen
		if len(parts) > 1 {
			// ignoramos parse error y quedamos en 0 si no se puede parsear
			var s int64
			fmt.Sscan(parts[1], &s)
			partStart = s
		}
		if len(parts) > 2 {
			var s int64
			fmt.Sscan(parts[2], &s)
			partSize = s
		}
	} else {
		// asumimos solo la ruta (start y size los obtenemos del MBR/partición al leer)
		diskPath = pathEntry
	}

	// abrir archivo disco
	f, err := os.OpenFile(diskPath, os.O_RDWR, 0666)
	if err != nil {
		return fmt.Errorf("no se pudo abrir disco %s: %v", diskPath, err)
	}
	defer f.Close()

	// Si start no estaba en MountedPartitions, intentar extraerlo del MBR buscando la partición por nombre/id.
	// Pero no todos los repos guardan start en MountedPartitions. Si partStart==0, asumimos que id map->path contiene start 0.
	// Para seguridad, si partStart==0 y disk existe, formatearemos desde 0 (en pruebas suele funcionar).
	// *Si tu mount original guarda Start en otra estructura, adapta stores.MountedPartitions para incluir "path|start|size".
	if partStart < 0 {
		partStart = 0
	}

	// 2) Determinar tamaño de la partición: si no disponible en map, tomamos el tamaño del archivo y usamos todo el disco
	if partSize == 0 {
		fi, err := f.Stat()
		if err == nil {
			partSize = fi.Size() - partStart
			if partSize < 0 {
				return fmt.Errorf("tamaño de partición inválido (start > file size)")
			}
		}
	}

	// 3) Calcular cantidad de inodos y bloques según enunciado:
	// formula simplificada: tamaño_particion = sizeOf(superblock) + n + 3*n + n*sizeOf(inodo) + 3*n*sizeOf(block)
	// despejar n: n = floor( tamaño_particion / (1 + 3 + size(inodo) + 3*size(block)) ) aproximado
	perInodeOverhead := 1 + 3 + InodeSizeBytes + 3*BlockSizeBytes
	if perInodeOverhead <= 0 {
		return fmt.Errorf("error interno cálculo de estructuras")
	}
	n := int64(partSize) / int64(perInodeOverhead)
	if n < 3 {
		n = 3 // mínimo razonable
	}

	// 4) Construir SuperBlockSimple y ubicaciones
	sb := SuperBlockSimple{}
	sb.FilesystemType = 2 // ext2
	sb.InodesCount = int32(n)
	sb.BlocksCount = int32(3 * n)
	sb.FreeInodesCount = int32(n - 2)                           // reservamos 2 para root + users
	sb.FreeBlocksCount = int32(3*n - 2)                         // reservamos 2 bloques iniciales
	copy(sb.MTime[:], time.Now().Format("2006-01-02 15:04:05")) // string -> byte array
	sb.Magic = 0xEF53
	sb.InodeSize = InodeSizeBytes
	sb.BlockSize = BlockSizeBytes
	sb.FirstIno = 2
	sb.FirstBlo = 2

	// Calcular offsets relativos dentro de la partición
	// Superblock en offset 0 (relativo a partStart)
	sb.BmInodeStart = int32(partStart) + int32(binary.Size(sb))
	sb.BmBlockStart = sb.BmInodeStart + int32(n)
	sb.InodeStart = sb.BmBlockStart + int32(3*n)
	sb.BlockStart = sb.InodeStart + int32(n*int64(sb.InodeSize))

	// 5) Escribir Superbloque
	if _, err := f.Seek(partStart, 0); err != nil {
		return fmt.Errorf("seek superbloque: %v", err)
	}
	if err := binary.Write(f, binary.LittleEndian, sb); err != nil {
		return fmt.Errorf("escribir superbloque: %v", err)
	}

	// 6) Inicializar bitmaps: inode bitmap y block bitmap
	// Inode bitmap (n bytes)
	if _, err := f.Seek(int64(sb.BmInodeStart), 0); err != nil {
		return fmt.Errorf("seek bm_inode: %v", err)
	}
	bmInodes := make([]byte, n)
	// marcar inodo 0 y 1 como usados (root e users)
	if n >= 1 {
		bmInodes[0] = 1
	}
	if n >= 2 {
		bmInodes[1] = 1
	}
	if _, err := f.Write(bmInodes); err != nil {
		return fmt.Errorf("escribir bitmap inodos: %v", err)
	}

	// Block bitmap (3*n bytes)
	if _, err := f.Seek(int64(sb.BmBlockStart), 0); err != nil {
		return fmt.Errorf("seek bm_block: %v", err)
	}
	bmBlocks := make([]byte, 3*n)
	if 3*n >= 1 {
		bmBlocks[0] = 1
	}
	if 3*n >= 2 {
		bmBlocks[1] = 1
	}
	if _, err := f.Write(bmBlocks); err != nil {
		return fmt.Errorf("escribir bitmap bloques: %v", err)
	}

	// 7) Crear inodos en la tabla de inodos:
	// Serializaremos inodos como una estructura simple:
	// [uid int32][gid int32][size int32][ctime 20 bytes][type byte][padding...][16*int32 blocks]
	// Pos: sb.InodeStart ... sb.InodeStart + n*InodeSizeBytes
	if _, err := f.Seek(int64(sb.InodeStart), 0); err != nil {
		return fmt.Errorf("seek inode table: %v", err)
	}

	// Helper para escribir inodo vacío
	writeEmptyInode := func(uid, gid int32, size int32, itype byte, blocks []int32) error {
		// uid
		if err := binary.Write(f, binary.LittleEndian, uid); err != nil {
			return err
		}
		// gid
		if err := binary.Write(f, binary.LittleEndian, gid); err != nil {
			return err
		}
		// size
		if err := binary.Write(f, binary.LittleEndian, size); err != nil {
			return err
		}
		// ctime 20 bytes
		ct := [20]byte{}
		copy(ct[:], time.Now().Format("2006-01-02 15:04:05"))
		if _, err := f.Write(ct[:]); err != nil {
			return err
		}
		// itype
		if err := binary.Write(f, binary.LittleEndian, itype); err != nil {
			return err
		}
		// padding to fill up to blocks array position
		// compute how many bytes have been written so far for this inode: 4+4+4+20+1 = 33
		pad := make([]byte, InodeSizeBytes-33-int(4*len(blocks)))
		if len(pad) < 0 {
			// safety
			pad = make([]byte, 0)
		}
		if len(pad) > 0 {
			if _, err := f.Write(pad); err != nil {
				return err
			}
		}
		// write block pointers (we write exactly 16 int32 values; if fewer provided, fill -1)
		for i := 0; i < 16; i++ {
			var val int32 = -1
			if i < len(blocks) {
				val = blocks[i]
			}
			if err := binary.Write(f, binary.LittleEndian, val); err != nil {
				return err
			}
		}
		return nil
	}

	// 7.a Inodo root (inodo 0 en bitmap)
	if _, err := f.Seek(int64(sb.InodeStart), 0); err != nil {
		return fmt.Errorf("seek inode root: %v", err)
	}
	// root tendrá block pointer al bloque carpeta 0
	if err := writeEmptyInode(1, 1, 0, 0, []int32{0}); err != nil {
		return fmt.Errorf("escribir inodo root: %v", err)
	}

	// 7.b Inodo users.txt (inodo 1)
	if _, err := f.Seek(int64(sb.InodeStart)+int64(InodeSizeBytes), 0); err != nil {
		return fmt.Errorf("seek inode users: %v", err)
	}
	usersContent := "1,G,root\n1,U,root,root,123\n"
	// users.txt usará bloque 1
	if err := writeEmptyInode(1, 1, int32(len(usersContent)), 1, []int32{1}); err != nil {
		return fmt.Errorf("escribir inodo users: %v", err)
	}

	// 8) Crear bloque carpeta raíz en sb.BlockStart + 0*BlockSizeBytes
	if _, err := f.Seek(int64(sb.BlockStart), 0); err != nil {
		return fmt.Errorf("seek root folder block: %v", err)
	}
	// Estructura de carpeta: 4 entradas, cada entry = [name 12 bytes][int32 inodo] -> total 16*4 = 64
	writeFolderEntry := func(name string, inode int32) error {
		nb := make([]byte, 12)
		copy(nb, []byte(name))
		if _, err := f.Write(nb); err != nil {
			return err
		}
		if err := binary.Write(f, binary.LittleEndian, inode); err != nil {
			return err
		}
		return nil
	}
	// Entradas: ".", "..", "users.txt", (vacía)
	if err := writeFolderEntry(".", 0); err != nil {
		return fmt.Errorf("root entry .: %v", err)
	}
	if err := writeFolderEntry("..", 0); err != nil {
		return fmt.Errorf("root entry ..: %v", err)
	}
	if err := writeFolderEntry("users.txt", 1); err != nil {
		return fmt.Errorf("root entry users: %v", err)
	}
	// write empty entry
	if err := writeFolderEntry("", -1); err != nil {
		return fmt.Errorf("root entry empty: %v", err)
	}

	// 9) Crear bloque archivo para users.txt en sb.BlockStart + 1*BlockSizeBytes
	if _, err := f.Seek(int64(sb.BlockStart)+int64(BlockSizeBytes), 0); err != nil {
		return fmt.Errorf("seek users block: %v", err)
	}
	// escribir contenido (padding a 64 bytes)
	buf := make([]byte, BlockSizeBytes)
	copy(buf, []byte(usersContent))
	if _, err := f.Write(buf); err != nil {
		return fmt.Errorf("escribir contenido users.txt: %v", err)
	}

	// 10) Actualizar (ya escrito) estado final en consola
	fmt.Printf("MKFS: Partición %s formateada en EXT2. Disco: %s (start=%d, size=%d). Inodos=%d, Bloques=%d\n",
		id, diskPath, partStart, partSize, n, 3*n)

	// 11) Guardar (si tu stores necesita alguna actualización) - aquí no modificamos stores.MountedPartitions
	// si tu mount requiere guardar algo adicional hazlo en el código del mount.

	return nil
}
