package commands

import (
	"errors"
	"fmt"
	"os"
	"regexp"
	"strings"
)

type RMDISK struct {
	path string
}

// ParserRmdisk parsea y ejecuta el comando rmdisk
func ParserRmdisk(tokens []string) (string, error) {
	cmd := &RMDISK{}

	// Unimos los tokens en una sola cadena
	args := strings.Join(tokens, " ")

	// Regex que soporta -path="..." o -path=/ruta
	re := regexp.MustCompile(`-path="[^"]+"|-path=[^\s]+`)
	matches := re.FindAllString(args, -1)

	if len(matches) == 0 {
		return "", errors.New("ERROR: faltan parámetros requeridos: -path")
	}

	// Validar que todos los tokens sean válidos
	for _, token := range tokens {
		if !re.MatchString(token) {
			return "", fmt.Errorf("ERROR: parámetro inválido o desconocido: %s", token)
		}
	}

	// Procesar matches
	for _, match := range matches {
		kv := strings.SplitN(match, "=", 2)
		if len(kv) != 2 {
			return "", fmt.Errorf("ERROR: formato de parámetro inválido: %s", match)
		}
		key := strings.ToLower(kv[0])
		value := kv[1]

		// Quitar comillas si existen
		if strings.HasPrefix(value, "\"") && strings.HasSuffix(value, "\"") {
			value = strings.Trim(value, "\"")
		}

		if key != "-path" {
			return "", fmt.Errorf("ERROR: parámetro desconocido: %s", key)
		}

		if value == "" {
			return "", errors.New("ERROR: el path no puede estar vacío")
		}
		cmd.path = value
	}

	// Verificar existencia del archivo
	if _, err := os.Stat(cmd.path); os.IsNotExist(err) {
		return "", errors.New("ERROR: el disco no existe en la ruta indicada")
	} else if err != nil {
		return "", fmt.Errorf("ERROR: error accediendo al archivo: %w", err)
	}

	// Eliminar disco
	if err := os.Remove(cmd.path); err != nil {
		return "", fmt.Errorf("ERROR: error eliminando disco: %w", err)
	}

	return fmt.Sprintf("RMDISK: Disco eliminado correctamente\n-> Path: %s", cmd.path), nil
}
